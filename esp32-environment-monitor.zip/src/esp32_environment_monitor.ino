/*
  ESP32 Smart Environment Monitoring System
  - Reads Temperature & Humidity from DHT22
  - RGB LED indicates humidity status (OK/WARN/HIGH)
  - Buzzer alerts when humidity is high
  - Slide switch triggers an interrupt to toggle Manual Override mode
    In Manual Override mode, RGB LED cycles colors (user-controlled) and
    automatic humidity indication is paused.

  Designed for:
  - Arduino IDE (ESP32 core)
  - PlatformIO
*/

#include <Arduino.h>
#include <DHT.h>

// -------------------- Pins (edit if needed) --------------------
static const int PIN_DHT = 15;        // DHT22 DATA pin
static const int PIN_RGB_R = 25;      // Red channel (PWM)
static const int PIN_RGB_G = 26;      // Green channel (PWM)
static const int PIN_RGB_B = 27;      // Blue channel (PWM)
static const int PIN_BUZZER = 14;     // Active buzzer / passive buzzer (tone)
static const int PIN_SWITCH = 33;     // Slide switch (interrupt-capable input)

// -------------------- DHT --------------------
#define DHTTYPE DHT22
DHT dht(PIN_DHT, DHTTYPE);

// -------------------- Thresholds (humidity %) --------------------
static const float HUMIDITY_OK_MAX   = 60.0;  // <= 60% => GREEN
static const float HUMIDITY_WARN_MAX = 75.0;  // 60–75% => YELLOW
// > 75% => RED + buzzer

// -------------------- Timing --------------------
static const uint32_t SENSOR_INTERVAL_MS = 2000; // DHT22 stable at ~2s intervals
static const uint32_t BUZZ_INTERVAL_MS   = 800;  // buzz cadence when alerting
static const uint32_t DEBOUNCE_MS        = 150;  // for switch interrupt debounce
static const uint32_t MANUAL_CYCLE_MS    = 1000; // cycle RGB every 1s in manual mode

// -------------------- PWM (ESP32 LEDC) --------------------
static const int PWM_FREQ = 5000;
static const int PWM_RES  = 8; // 0..255
static const int CH_R = 0;
static const int CH_G = 1;
static const int CH_B = 2;

// -------------------- State --------------------
volatile bool g_switchEvent = false;
volatile uint32_t g_lastIsrMs = 0;

bool manualOverride = false;
uint8_t manualColorIndex = 0;

uint32_t lastSensorMs = 0;
uint32_t lastBuzzMs = 0;
uint32_t lastManualCycleMs = 0;
bool buzzOn = false;

float lastTempC = NAN;
float lastHum = NAN;

// -------------------- Helpers --------------------
void setRGB(uint8_t r, uint8_t g, uint8_t b) {
  ledcWrite(CH_R, r);
  ledcWrite(CH_G, g);
  ledcWrite(CH_B, b);
}

// common colours
void rgbGreen()  { setRGB(0, 255, 0); }
void rgbYellow() { setRGB(255, 150, 0); }
void rgbRed()    { setRGB(255, 0, 0); }
void rgbBlue()   { setRGB(0, 0, 255); }
void rgbPurple() { setRGB(180, 0, 255); }
void rgbWhite()  { setRGB(180, 180, 180); }
void rgbOff()    { setRGB(0, 0, 0); }

void applyAutoHumidityIndicator(float hum) {
  if (isnan(hum)) {
    // sensor read failed => show purple as "error"
    rgbPurple();
    return;
  }
  if (hum <= HUMIDITY_OK_MAX) {
    rgbGreen();
  } else if (hum <= HUMIDITY_WARN_MAX) {
    rgbYellow();
  } else {
    rgbRed();
  }
}

bool isAlertHumidity(float hum) {
  return (!isnan(hum) && hum > HUMIDITY_WARN_MAX);
}

void buzzerOff() {
  buzzOn = false;
  // If using active buzzer, just set LOW:
  digitalWrite(PIN_BUZZER, LOW);
  // For passive buzzer with tone(), we'd call noTone(PIN_BUZZER) instead.
}

void buzzerToggle() {
  buzzOn = !buzzOn;
  digitalWrite(PIN_BUZZER, buzzOn ? HIGH : LOW);
}

void cycleManualColour() {
  manualColorIndex = (manualColorIndex + 1) % 6;
  switch (manualColorIndex) {
    case 0: rgbBlue(); break;
    case 1: rgbGreen(); break;
    case 2: rgbYellow(); break;
    case 3: rgbRed(); break;
    case 4: rgbPurple(); break;
    default: rgbWhite(); break;
  }
}

// -------------------- Interrupt --------------------
void IRAM_ATTR onSwitchChange() {
  uint32_t now = millis();
  if (now - g_lastIsrMs < DEBOUNCE_MS) return;
  g_lastIsrMs = now;
  g_switchEvent = true;
}

// -------------------- Setup / Loop --------------------
void setup() {
  Serial.begin(115200);
  delay(200);

  // DHT
  dht.begin();

  // Buzzer
  pinMode(PIN_BUZZER, OUTPUT);
  buzzerOff();

  // Switch (use pull-up; switch to GND when ON)
  pinMode(PIN_SWITCH, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(PIN_SWITCH), onSwitchChange, CHANGE);

  // PWM for RGB
  ledcSetup(CH_R, PWM_FREQ, PWM_RES);
  ledcSetup(CH_G, PWM_FREQ, PWM_RES);
  ledcSetup(CH_B, PWM_FREQ, PWM_RES);
  ledcAttachPin(PIN_RGB_R, CH_R);
  ledcAttachPin(PIN_RGB_G, CH_G);
  ledcAttachPin(PIN_RGB_B, CH_B);

  rgbOff();

  Serial.println("ESP32 Environment Monitor started.");
  Serial.println("Switch toggles Manual Override mode.");
}

void loop() {
  uint32_t now = millis();

  // Handle switch event
  if (g_switchEvent) {
    noInterrupts();
    g_switchEvent = false;
    interrupts();

    // Toggle manual mode
    manualOverride = !manualOverride;
    Serial.print("Manual Override: ");
    Serial.println(manualOverride ? "ON" : "OFF");

    // Reset behaviours on toggle
    buzzerOff();
    lastBuzzMs = now;
    lastManualCycleMs = now;

    if (manualOverride) {
      manualColorIndex = 255; // so first cycle goes to 0
      cycleManualColour();
    } else {
      applyAutoHumidityIndicator(lastHum);
    }
  }

  // Sensor read (always keep updating in background for logging)
  if (now - lastSensorMs >= SENSOR_INTERVAL_MS) {
    lastSensorMs = now;

    float h = dht.readHumidity();
    float t = dht.readTemperature();

    // Basic validation: DHT can return NaN on failure
    lastHum = h;
    lastTempC = t;

    Serial.print("Humidity: ");
    if (isnan(h)) Serial.print("NaN"); else Serial.print(h, 1);
    Serial.print("%  | Temp: ");
    if (isnan(t)) Serial.print("NaN"); else Serial.print(t, 1);
    Serial.println("C");

    // Apply automatic indicator only when not in manual override
    if (!manualOverride) {
      applyAutoHumidityIndicator(lastHum);
    }
  }

  // Manual override colour cycling
  if (manualOverride && (now - lastManualCycleMs >= MANUAL_CYCLE_MS)) {
    lastManualCycleMs = now;
    cycleManualColour();
  }

  // Buzzer alert in auto mode when humidity is high
  if (!manualOverride && isAlertHumidity(lastHum)) {
    if (now - lastBuzzMs >= BUZZ_INTERVAL_MS) {
      lastBuzzMs = now;
      buzzerToggle();
    }
  } else {
    // Ensure buzzer is off if not alerting
    if (buzzOn) buzzerOff();
  }
}
